import 'package:mutfak/men%C3%BCler/%C3%87orbalar.dart';
import 'package:mutfak/men%C3%BCler/Ana%20Yemek.dart';
import 'package:mutfak/men%C3%BCler/Cay%20Keyfi.dart';
import 'package:mutfak/men%C3%BCler/Tatl%C4%B1lar.dart';
import 'package:mutfak/pages/DosyaYazma.dart';
import 'package:mutfak/services/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:mutfak/men%C3%BCler/BeytiKebabi.dart';
import 'package:mutfak/men%C3%BCler/Borek.dart';
import 'package:mutfak/men%C3%BCler/Gullac.dart';
import 'package:mutfak/men%C3%BCler/Kek.dart';
import 'package:mutfak/men%C3%BCler/Kunefe.dart';
import 'package:mutfak/men%C3%BCler/Kurabiye.dart';
import 'package:mutfak/men%C3%BCler/MercimekCorbasi.dart';
import 'package:mutfak/men%C3%BCler/Sarma.dart';
import 'package:mutfak/pages/login.dart';
import 'package:mutfak/pages/add_status.dart';
import 'package:mutfak/Veritabanı/YemekListem.dart';
import 'package:rive/rive.dart';

import 'package:mutfak/services/albums_services.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  AuthService _authService = AuthService();
  double angle = 0.0;

  void _onPanUpdateHandler(DragUpdateDetails details) {
    final touchPositionFromCenter = details.localPosition;
    setState(
      () {
        angle = touchPositionFromCenter.direction;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(160, 160, 160, 1),
      appBar: AppBar(
        title: Text('Mutfağım'),
        backgroundColor: Colors.red,
      ),
      body: Stack(children: <Widget>[
        RiveAnimation.asset('assets/lolipop.riv'),
        SingleChildScrollView(
          child: Column(children: <Widget>[
            Row(
              children: [
                GestureDetector(
                  onDoubleTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Tatlilar())),
                  onPanUpdate: _onPanUpdateHandler,
                  child: Container(
                    alignment: Alignment.center,
                    child: Transform.rotate(
                      angle: angle,
                      child: Container(
                        color: Colors.red,
                        child: SizedBox(
                          height: 50,
                          width: 100,
                          child: Text('Tatlilar'),
                        ),
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTapUp: (e) => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Corbalar())),
                  onPanUpdate: _onPanUpdateHandler,
                  child: Container(
                    alignment: Alignment.center,
                    child: Transform.rotate(
                      angle: angle,
                      child: Container(
                        color: Colors.red,
                        child: SizedBox(
                          height: 50,
                          width: 100,
                          child: Text('Çorbalar'),
                        ),
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTapDown: (e) => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => AnaYemek())),
                  onPanUpdate: _onPanUpdateHandler,
                  child: Container(
                    child: Transform.rotate(
                      angle: angle,
                      child: Container(
                        alignment: Alignment.center,
                        color: Colors.red,
                        child: SizedBox(
                          height: 50,
                          width: 110,
                          child: Text('Ana Yemek'),
                        ),
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onLongPress: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => CayKeyfi())),
                  onPanUpdate: _onPanUpdateHandler,
                  child: Container(
                    child: Transform.rotate(
                      angle: angle,
                      child: Container(
                        alignment: Alignment.center,
                        color: Colors.red,
                        child: SizedBox(
                          height: 50,
                          width: 100,
                          child: Text('Çay Keyfi'),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Sarma())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/sarm.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Sarma Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Kurabiye())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/kurabiye.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Kurabiye Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Borek())),
              child: Container(
                width: 400,
                height: 280,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/borek.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Börek Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Kunefe())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/kunefe.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Künefe Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => MercimekCorbasi())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/mercimekcorbası.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Mercimek Çorbası Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => BeytiKebabi())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                    ),
                    Image.asset("assets/images/beytikebabı.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Beyti Kebabı Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Gullac())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/gullac.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Güllaç Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Kek())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/kek.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Kek Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ]),
        ),
      ]),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text("Merhaba"),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage("assets/images/beyaz.png"),
              ),
            ),
            ListTile(
              title: Text('Anasayfa'),
              leading: Icon(Icons.home),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('Profilim'),
              onTap: () {
                Navigator.pop(context);
              },
              leading: Icon(Icons.person),
            ),
            ListTile(
              title: Text('Hazırladığım Yemekler'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AddStatusPage())),
              leading: Icon(Icons.person),
            ),
            ListTile(
              title: Text('Beğendiğim Yemekler'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => StudentPage())),
              leading: Icon(Icons.person),
            ),
            ListTile(
              title: Text('Kullanıcılar'),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Album())),
              leading: Icon(Icons.person),
            ),
            ListTile(
              title: Text('Dosyaya yazma'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => DosyaYazma())),
              leading: Icon(Icons.person),
            ),
            Divider(),
            ListTile(
              title: Text('Çıkış yap'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => LoginPage())),
              leading: Icon(Icons.remove_circle),
            ),
          ],
        ),
      ),
    );
  }
}
