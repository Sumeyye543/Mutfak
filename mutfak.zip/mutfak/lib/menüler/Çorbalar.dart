import 'package:flutter/material.dart';

import 'Gullac.dart';
import 'Kunefe.dart';
import 'Kurabiye.dart';
import 'MercimekCorbasi.dart';

class Corbalar extends StatefulWidget {
  @override
  _CorbalarState createState() => _CorbalarState();
}

class _CorbalarState extends State<Corbalar> {
  double _width = 100;
  double _height = 50;
  double _updatestate() {
    setState(() {
      _width = 100;
      _height = 50;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.deepOrangeAccent,
        appBar: AppBar(title: Text('Mutfağım')),
        body: SafeArea(
            child: SingleChildScrollView(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
              GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MercimekCorbasi())),
                child: Container(
                  width: 400,
                  height: 270,
                  margin: EdgeInsets.all(5.0),
                  alignment: Alignment.center,
                  child: Column(
                    children: <Widget>[
                      Image.asset("assets/images/mercimekcorbası.png"),
                      FittedBox(
                        fit: BoxFit.fitHeight,
                        child: Text(
                          "Mercimek Çorbası Tarifi",
                          style: TextStyle(fontSize: 40.0),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ]))));
  }
}
