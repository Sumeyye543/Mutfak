import 'package:flutter/material.dart';

import 'BeytiKebabi.dart';
import 'Gullac.dart';
import 'Kunefe.dart';
import 'Kurabiye.dart';

class AnaYemek extends StatefulWidget {
  @override
  _AnaYemekState createState() => _AnaYemekState();
}

class _AnaYemekState extends State<AnaYemek> {
  double _width = 100;
  double _height = 50;
  double _updatestate() {
    setState(() {
      _width = 100;
      _height = 50;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.deepOrangeAccent,
        appBar: AppBar(title: Text('Mutfağım')),
        body: SafeArea(
            child: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => BeytiKebabi())),
                  child: Container(
                    width: 400,
                    height: 270,
                    margin: EdgeInsets.all(5.0),
                    alignment: Alignment.center,
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                        ),
                        Image.asset("assets/images/beytikebabı.png"),
                        FittedBox(
                          fit: BoxFit.fitHeight,
                          child: Text(
                            "Beyti Kebabı Tarifi",
                            style: TextStyle(fontSize: 40.0),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ]),
        )));
  }
}
