import 'package:flutter/material.dart';

import 'Borek.dart';
import 'Gullac.dart';
import 'Kunefe.dart';
import 'Kurabiye.dart';

class CayKeyfi extends StatefulWidget {
  @override
  _CayKeyfiState createState() => _CayKeyfiState();
}

class _CayKeyfiState extends State<CayKeyfi> {
  double _width = 100;
  double _height = 50;
  double _updatestate() {
    setState(() {
      _width = 100;
      _height = 50;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.deepOrangeAccent,
        appBar: AppBar(title: Text('Mutfağım')),
        body: SafeArea(
            child: SingleChildScrollView(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <
              Widget>[
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Borek())),
              child: Container(
                width: 400,
                height: 280,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/borek.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Börek Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Kunefe())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/kunefe.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Künefe Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Gullac())),
              child: Container(
                width: 400,
                height: 270,
                margin: EdgeInsets.all(5.0),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Image.asset("assets/images/gullac.png"),
                    FittedBox(
                      fit: BoxFit.fitHeight,
                      child: Text(
                        "Güllaç Tarifi",
                        style: TextStyle(fontSize: 40.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ]),
        )));
  }
}
