package com.example.mutfak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
